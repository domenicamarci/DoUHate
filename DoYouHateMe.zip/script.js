
// Seleziona gli elementi
const yesButton = document.getElementById('yes-button');
const noButton = document.getElementById('no-button');
const question = document.querySelector('.question');
const yesResponse = document.querySelector('.yes-response');
const noResponse = document.querySelector('.no-response');

// Mostra la schermata "Yes"
yesButton.addEventListener('click', () => {
  question.classList.add('hidden');
  yesResponse.classList.remove('hidden');
});

// Mostra la schermata "No"
noButton.addEventListener('click', () => {
  question.classList.add('hidden');
  noResponse.classList.remove('hidden');
});
